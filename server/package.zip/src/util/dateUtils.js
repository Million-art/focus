// dateUtils.js
const getCurrentDate = () => {
    return new Date();
  };
  
  module.exports = {
    getCurrentDate,
  };
  